package com.example.jpark6694.my_app_cs_m117;

import android.app.Activity;
import android.os.Bundle;

/**
 * Created by JPARK6694 on 5/21/2016.
 */
public class thankYou extends Display_1 {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.thank_you);
    }
}
