package com.example.jpark6694.my_app_cs_m117;

import android.app.Activity;
import android.os.Bundle;

/**
 * Created by JPARK6694 on 5/21/2016.
 */
public class DAF_PRETTY_GG extends Activity{
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.daf_pretty_gg);
    }
}
