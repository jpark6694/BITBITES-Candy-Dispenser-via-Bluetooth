package com.example.jpark6694.my_app_cs_m117;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;

/**
 * Created by JPARK6694 on 5/21/2016.
 */
public class Display_1 extends Activity implements View.OnClickListener {

    Button myButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.display_1);

        myButton = (Button) findViewById(R.id.button);

        myButton.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        if (view.equals(myButton))
        {
            Intent b_1 = new Intent(Display_1.this,thankYou.class);
            startActivity(b_1);
        }
    }
}