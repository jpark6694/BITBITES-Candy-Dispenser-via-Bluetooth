package com.example.jpark6694.my_app_cs_m117;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.support.v7.app.ActionBar;
import android.support.v7.app.ActionBarActivity;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity{

    ListView list;
    Button buttonBluetooth;
    String[] candyTitles;
    String[] candyPrices;
    String[] candyClick;

    int[] candy_images = {R.drawable.gumball, R.drawable.gummy_worm, R.drawable.jelly_bean, R.drawable.jolly_rancher, R.drawable.life_savers,
            R.drawable.skittles, R.drawable.m_m, R.drawable.orbit, R.drawable.joel, R.drawable.franklin,
            R.drawable.akshaya, R.drawable.gary};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Resources res = getResources();
        candyTitles = res.getStringArray(R.array.titles);
        candyPrices = res.getStringArray(R.array.prices);
        candyClick = res.getStringArray(R.array.clk);

        list = (ListView) findViewById(R.id.listView);
        buttonBluetooth = (Button) findViewById(R.id.button2);
        VivzAdapter adapter = new VivzAdapter(this, candyTitles, candy_images, candyPrices);
        list.setAdapter(adapter);

        buttonBluetooth.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent b_1 = new Intent(MainActivity.this, Bluetooth.class);
                startActivity(b_1);
            }
        });

        list.setOnItemClickListener(
                new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> arg0, View view, int position, long id) {
                        Object o = list.getItemAtPosition(position);
                        String pen = o.toString();
                        System.out.println(position);
                        if (candyClick[position].compareTo(candyClick[0]) == 0) {
                            Intent i_1 = new Intent(MainActivity.this, Display_1.class);
                            startActivity(i_1);
                        } else if (candyClick[position].compareTo(candyClick[10]) == 0) {
                            Intent daf = new Intent(MainActivity.this, DAF_PRETTY_GG.class);
                            startActivity(daf);
                        } else {
                            Toast.makeText(getApplicationContext(), candyClick[position], Toast.LENGTH_LONG).show();
                        }
                    }
                }
        );
    }
}

class VivzAdapter extends ArrayAdapter<String> {
    Context context;
    int images[];
    String[] titleArray, priceArray;

    VivzAdapter(Context c, String[] titles, int imgs[], String[] prices) {
        super(c, R.layout.single_row, R.id.textView, titles);
        this.context = c;
        this.images = imgs;
        this.titleArray = titles;
        this.priceArray = prices;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View row = inflater.inflate(R.layout.single_row, parent, false);
        ImageView myImage = (ImageView) row.findViewById(R.id.imageView);
        TextView MyTitle = (TextView) row.findViewById(R.id.textView);
        TextView MyPrice = (TextView) row.findViewById(R.id.textView2);

        myImage.setImageResource(images[position]);
        MyTitle.setText(titleArray[position]);
        MyPrice.setText(priceArray[position]);

        return row;
    }

}